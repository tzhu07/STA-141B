# sta141cproject
about the housing price prediction
The goal of this project is to determine the estimated price and find the relationship between house features and how these variables are used to predict the house price.
we use method relate with lm, QR, LU, Cholesky, AIC, and predict the saling price. 
